import React from 'react'
import DashboardLayout from '@/Layouts/AdministrationPanelLayout/DashboardLayout'
import { Plus } from 'lucide-react'
import { Head, Link } from '@inertiajs/react'


export default function Index() {
    return (
        <div className="min-h-screen bg-gray-50 p-4 lg:p-6">
            <Head title="Variant Management" />

            {/* Page Header */}
            <div className="mb-5 flex flex-wrap items-center justify-between gap-4 border-b border-gray-200 pb-5">
                <div>
                    <h1 className="text-xl font-semibold text-gray-800">Product Management</h1>
                    <p className="text-sm text-gray-500">
                        Manage your products and their variants.
                    </p>
                </div>
                <Link
                    href={route('admin.stock.product.create')}
                    className="flex items-center gap-2 rounded-lg bg-violet-600 px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-violet-700 active:scale-[0.98]"
                >
                    <Plus size={18} />
                    <span>Create Product</span>
                </Link>
            </div>

           
        </div>
    )
}

Index.layout = (page) => <DashboardLayout title="Product Management">{page}</DashboardLayout>