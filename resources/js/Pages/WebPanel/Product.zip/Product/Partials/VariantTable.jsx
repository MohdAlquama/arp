import React from "react";
import {
    ImagePlus,
    Trash2,
    Package,
    CheckCircle2,
} from "lucide-react";

const FieldError = ({ message }) =>
    message ? (
        <p className="mt-1 text-xs text-red-600">{message}</p>
    ) : null;

export default function VariantTable({
    variations = [],
    imagePreviews = {},
    errors = {},
    onImageUpload,
    onRemoveImage,
}) {
    return (
        <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="text-sm font-semibold text-gray-800">
                    Variant Management
                </h3>

                <span className="rounded-full bg-violet-50 px-3 py-1 text-xs font-semibold text-violet-700">
                    {variations.length} Variations
                </span>
            </div>

            <div className="overflow-x-auto rounded-lg border border-gray-200">
                <table className="w-full min-w-[650px] text-left text-sm">
                    <thead className="bg-gray-50 text-xs uppercase text-gray-600">
                        <tr>
                            <th className="px-4 py-3">#</th>
                            <th className="px-4 py-3">Color</th>
                            <th className="px-4 py-3">Size</th>
                            <th className="px-4 py-3">Product Image</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3">Action</th>
                        </tr>
                    </thead>

                    <tbody className="divide-y divide-gray-100">
                        {variations.length > 0 ? (
                            variations.map((variation, index) => {
                                const preview =
                                    imagePreviews[index] ||
                                    variation.existing_image_url;

                                return (
                                    <tr
                                        key={`${variation.color_id}-${variation.size_id}-${index}`}
                                        className="transition hover:bg-gray-50"
                                    >
                                        <td className="px-4 py-4 text-gray-500">
                                            {index + 1}
                                        </td>

                                        <td className="px-4 py-4 font-medium text-gray-800">
                                            {variation.color_name || "-"}
                                        </td>

                                        <td className="px-4 py-4">
                                            <span className="rounded-md bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-700">
                                                {variation.size_name || "-"}
                                            </span>
                                        </td>

                                        <td className="px-4 py-4">
                                            <div className="flex items-center gap-3">
                                                {preview ? (
                                                    <img
                                                        src={preview}
                                                        alt="Variant"
                                                        className="h-14 w-14 rounded-lg border object-cover"
                                                    />
                                                ) : (
                                                    <label className="flex h-14 w-14 cursor-pointer items-center justify-center rounded-lg border-2 border-dashed border-gray-300 bg-gray-50 text-gray-400 hover:border-violet-400 hover:bg-violet-50 hover:text-violet-600">
                                                        <ImagePlus size={20} />

                                                        <input
                                                            type="file"
                                                            accept="image/jpeg,image/png,image/webp"
                                                            className="hidden"
                                                            onChange={(e) => {
                                                                onImageUpload(
                                                                    index,
                                                                    e.target.files?.[0]
                                                                );
                                                                e.target.value = "";
                                                            }}
                                                        />
                                                    </label>
                                                )}

                                                <div>
                                                    <p className="max-w-[130px] truncate text-xs font-medium text-gray-700">
                                                        {variation.image instanceof File
                                                            ? variation.image.name
                                                            : preview
                                                              ? "Image uploaded"
                                                              : "Upload Image"}
                                                    </p>

                                                    <p className="text-xs text-gray-400">
                                                        JPG, PNG, WEBP
                                                    </p>

                                                    {preview && (
                                                        <label className="mt-1 block cursor-pointer text-xs font-medium text-violet-600 hover:text-violet-800">
                                                            Change Image
                                                            <input
                                                                type="file"
                                                                accept="image/jpeg,image/png,image/webp"
                                                                className="hidden"
                                                                onChange={(e) => {
                                                                    onImageUpload(
                                                                        index,
                                                                        e.target.files?.[0]
                                                                    );
                                                                    e.target.value = "";
                                                                }}
                                                            />
                                                        </label>
                                                    )}
                                                </div>
                                            </div>

                                            <FieldError
                                                message={
                                                    errors[`variations.${index}.image`]
                                                }
                                            />
                                        </td>

                                        <td className="px-4 py-4">
                                            {preview ? (
                                                <span className="inline-flex items-center gap-1 rounded-full bg-green-50 px-2.5 py-1 text-xs font-medium text-green-700">
                                                    <CheckCircle2 size={13} />
                                                    Uploaded
                                                </span>
                                            ) : (
                                                <span className="rounded-full bg-yellow-50 px-2.5 py-1 text-xs font-medium text-yellow-700">
                                                    Pending
                                                </span>
                                            )}
                                        </td>

                                        <td className="px-4 py-4">
                                            {preview && (
                                                <button
                                                    type="button"
                                                    onClick={() =>
                                                        onRemoveImage(index)
                                                    }
                                                    className="rounded-lg p-2 text-red-500 hover:bg-red-50 hover:text-red-700"
                                                    title="Remove Image"
                                                >
                                                    <Trash2 size={17} />
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                );
                            })
                        ) : (
                            <tr>
                                <td
                                    colSpan="6"
                                    className="px-4 py-12 text-center"
                                >
                                    <Package
                                        size={35}
                                        className="mx-auto mb-3 text-gray-300"
                                    />

                                    <p className="text-sm font-medium text-gray-600">
                                        No Variations Found
                                    </p>

                                    <p className="mt-1 text-xs text-gray-400">
                                        Please select an article to load color
                                        and size combinations.
                                    </p>
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            <FieldError message={errors.variations} />
        </div>
    );
}