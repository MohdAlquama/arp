import React, { useEffect, useRef, useState } from "react";
import { useForm, Link } from "@inertiajs/react";

import {
    Box,
    Layers,
    ImagePlus,
    Megaphone,
    Globe,
} from "lucide-react";

import SearchableSelect from "./Searchableselect";
import FormSection from "./FormSection";
import VariantTable from "./VariantTable";
import ProductPromotional from "./ProductPromotional";
import ProductImage from "./ProductImage";
import ProductPublish from "./ProductPublish";

const inputClass =
    "w-full rounded-lg border border-gray-300 bg-white px-3.5 py-2.5 text-sm focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20";

const Label = ({ children }) => (
    <label className="mb-1.5 block text-sm font-medium text-gray-700">
        {children}
    </label>
);

const FieldError = ({ message }) =>
    message ? (
        <p className="mt-1.5 text-sm text-red-600">{message}</p>
    ) : null;

export default function ProductForm({
    variants = [],
    product = null,
}) {
    const isEditing = Boolean(product?.id);

    const [imagePreviews, setImagePreviews] = useState({});
    const previewUrls = useRef([]);

    const {
        data,
        setData,
        post,
        put,
        processing,
        errors,
    } = useForm({
        variant_id: product?.variant_id ?? "",

        article_no: product?.article_no ?? "",
        default_name: product?.default_name ?? "",

        category_name: product?.category_name ?? "",
        sub_category_name: product?.sub_category_name ?? "",
        material_name: product?.material_name ?? "",

        // Main product image
        product_image: null,
        remove_product_image: false,

        // Product promotional
        is_promotional: Boolean(product?.is_promotional ?? false),

        // Product publish
        is_published: Boolean(product?.is_published ?? false),

        // Color and size variations
        variations:
            product?.variations?.map((item) => ({
                color_id: item.color_id ?? "",
                color_name: item.color_name ?? "",
                size_id: item.size_id ?? "",
                size_name: item.size_name ?? "",

                image: null,
                existing_image_url:
                    item.image_url ??
                    (typeof item.image === "string" ? item.image : ""),

                remove_image: false,
            })) ?? [],
    });

    // Cleanup preview URLs
    useEffect(() => {
        return () => {
            previewUrls.current.forEach((url) => {
                URL.revokeObjectURL(url);
            });
        };
    }, []);

    // Variant dropdown options
    const variantOptions = variants.map((variant) => ({
        value: variant.id,
        label: `${variant.article_no} - ${variant.default_name}`,
    }));

    // Select article / variant
    const handleVariantChange = (id) => {
        const selectedVariant = variants.find(
            (variant) => String(variant.id) === String(id)
        );

        if (!selectedVariant) return;

        setImagePreviews({});

        const variations = (
            selectedVariant.attribute_pairs ?? []
        ).map((item) => ({
            color_id: item.color_id ?? "",
            color_name: item.color_name ?? "",
            size_id: item.size_id ?? "",
            size_name: item.size_name ?? "",

            image: null,
            existing_image_url: "",
            remove_image: false,
        }));

        setData((prev) => ({
            ...prev,

            variant_id: selectedVariant.id,

            article_no: selectedVariant.article_no ?? "",
            default_name: selectedVariant.default_name ?? "",

            category_name: selectedVariant.category_name ?? "",
            sub_category_name:
                selectedVariant.sub_category_name ?? "",
            material_name: selectedVariant.material_name ?? "",

            variations,
        }));
    };

    // Upload variation image
    const handleImageUpload = (index, file) => {
        if (!file) return;

        if (!file.type.startsWith("image/")) return;

        const preview = URL.createObjectURL(file);
        previewUrls.current.push(preview);

        setData(
            "variations",
            data.variations.map((item, i) =>
                i === index
                    ? {
                          ...item,
                          image: file,
                          remove_image: false,
                      }
                    : item
            )
        );

        setImagePreviews((prev) => ({
            ...prev,
            [index]: preview,
        }));
    };

    // Remove variation image
    const removeImage = (index) => {
        setData(
            "variations",
            data.variations.map((item, i) =>
                i === index
                    ? {
                          ...item,
                          image: null,
                          existing_image_url: "",
                          remove_image: true,
                      }
                    : item
            )
        );

        setImagePreviews((prev) => {
            const updated = { ...prev };
            delete updated[index];
            return updated;
        });
    };

    // Upload main product image
    const handleProductImageChange = (file) => {
        setData((prev) => ({
            ...prev,
            product_image: file,
            remove_product_image: false,
        }));
    };

    // Remove main product image
    const handleProductImageRemove = () => {
        setData((prev) => ({
            ...prev,
            product_image: null,
            remove_product_image: true,
        }));
    };

    // Submit form
    const handleSubmit = (e) => {
        e.preventDefault();

        const options = {
            forceFormData: true,
            preserveScroll: true,
        };

        if (isEditing) {
            put(
                route("admin.stock.product.update", product.id),
                options
            );
        } else {
            post(
                route("admin.stock.product.store"),
                options
            );
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-8">

            {/* STEP 1: ARTICLE SELECTION */}

            <FormSection
                step="Step 1: Article Selection"
                icon={Box}
                title="Select Article"
                description="Select an article from your variant master to fetch product information."
            >
                <div>
                    <Label>Select Article</Label>

                    <SearchableSelect
                        value={data.variant_id}
                        onChange={handleVariantChange}
                        options={variantOptions}
                        placeholder="Select Article"
                        searchPlaceholder="Search article number..."
                    />

                    <FieldError message={errors.variant_id} />
                </div>
            </FormSection>

            {/* STEP 2: PRODUCT INFORMATION */}

            <FormSection
                step="Step 2: Product Details"
                icon={Layers}
                title="Product Information"
                description="Selected article information will automatically appear here."
            >
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">

                    <div>
                        <Label>Article Number</Label>

                        <input
                            type="text"
                            value={data.article_no}
                            readOnly
                            placeholder="Article Number"
                            className={`${inputClass} bg-gray-50`}
                        />
                    </div>

                    <div>
                        <Label>Product Name</Label>

                        <input
                            type="text"
                            value={data.default_name}
                            readOnly
                            placeholder="Product Name"
                            className={`${inputClass} bg-gray-50`}
                        />
                    </div>

                    <div>
                        <Label>Category</Label>

                        <input
                            type="text"
                            value={data.category_name}
                            readOnly
                            placeholder="Category"
                            className={`${inputClass} bg-gray-50`}
                        />
                    </div>

                    <div>
                        <Label>Sub Category</Label>

                        <input
                            type="text"
                            value={data.sub_category_name}
                            readOnly
                            placeholder="Sub Category"
                            className={`${inputClass} bg-gray-50`}
                        />
                    </div>

                    <div>
                        <Label>Material</Label>

                        <input
                            type="text"
                            value={data.material_name}
                            readOnly
                            placeholder="Material"
                            className={`${inputClass} bg-gray-50`}
                        />
                    </div>

                </div>
            </FormSection>

            {/* STEP 3: VARIANT TABLE */}

            <FormSection
                step="Step 3: Variant Management"
                icon={Layers}
                title="Variant Table"
                description="Manage color and size combinations and upload individual variation images."
            >
                <VariantTable
                    variations={data.variations}
                    imagePreviews={imagePreviews}
                    errors={errors}
                    onImageUpload={handleImageUpload}
                    onRemoveImage={removeImage}
                />
            </FormSection>

            {/* STEP 4: PRODUCT IMAGE */}

            <FormSection
                step="Step 4: Product Image"
                icon={ImagePlus}
                title="Main Product Image"
                description="Upload the main image that represents this product."
            >
                <ProductImage
                    value={data.product_image}
                    existingImage={
                        data.remove_product_image
                            ? ""
                            : product?.image_url ?? ""
                    }
                    onChange={handleProductImageChange}
                    onRemove={handleProductImageRemove}
                    error={errors.product_image}
                />
            </FormSection>

            {/* STEP 5: PROMOTIONAL */}

            <FormSection
                step="Step 5: Promotional"
                icon={Megaphone}
                title="Product Promotional"
                description="Choose whether this product should be marked as promotional."
            >
                <ProductPromotional
                    value={data.is_promotional}
                    onChange={(value) =>
                        setData("is_promotional", value)
                    }
                />

                <FieldError message={errors.is_promotional} />
            </FormSection>

            {/* STEP 6: PUBLISH */}

            <FormSection
                step="Step 6: Publish"
                icon={Globe}
                title="Product Publish"
                description="Control the product visibility on your website."
            >
                <ProductPublish
                    value={data.is_published}
                    onChange={(value) =>
                        setData("is_published", value)
                    }
                />

                <FieldError message={errors.is_published} />
            </FormSection>

            {/* ACTION BUTTONS */}

            <div className="flex items-center justify-end gap-3">

                <Link
                    href={route("admin.stock.product.index")}
                    className="rounded-lg bg-white px-5 py-2.5 text-sm font-medium text-gray-700 shadow-sm ring-1 ring-inset ring-gray-300 transition hover:bg-gray-50"
                >
                    Cancel
                </Link>

                <button
                    type="submit"
                    disabled={processing || !data.variant_id}
                    className="rounded-lg bg-violet-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-violet-700 disabled:cursor-not-allowed disabled:opacity-60"
                >
                    {processing
                        ? "Saving..."
                        : isEditing
                          ? "Update Product"
                          : "Create Product"}
                </button>

            </div>
        </form>
    );
}