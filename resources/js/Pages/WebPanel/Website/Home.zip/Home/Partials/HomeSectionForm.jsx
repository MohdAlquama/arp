import React, { useState, useRef } from 'react'
import { useForm, router } from '@inertiajs/react'
import {
    Layout,
    Image as ImageIcon,
    MousePointerClick,
    Activity,
    Save,
    Link as LinkIcon,
    Type,
    Upload,
    Trash2
} from 'lucide-react'

export const FormSection = ({ step, icon: Icon, title, description, children }) => (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="lg:col-span-4">
            <div className="mb-1 flex items-center gap-2 text-sm font-semibold text-violet-600">
                <Icon size={18} />
                <span>{step}</span>
            </div>

            <h2 className="text-base font-semibold text-gray-900">
                {title}
            </h2>

            <p className="mt-1 text-sm text-gray-500">
                {description}
            </p>
        </div>

        <div className="lg:col-span-8">
            <div className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
                {children}
            </div>
        </div>
    </div>
)

function HomeSectionForm({ section = {} }) {
    const isEditing = Boolean(section?.id)
    const fileInputRef = useRef(null)

    const {
        data: formData,
        setData: setFormData,
        post,
        processing,
        errors
    } = useForm({
        title: section?.title || '',
        description: section?.description || '',
        image: null,
        remove_image: false,
        has_button: section?.has_button ?? false,
        button_text: section?.button_text || '',
        button_link: section?.button_link || '',
        status: section?.status ?? true,
    })

    const [imagePreview, setImagePreview] = useState(section?.image_url || null)

    // Handle Image Selection & Local Preview
    const handleImageChange = (event) => {
        const file = event.target.files?.[0]
        if (!file) return

        setFormData((prev) => ({
            ...prev,
            image: file,
            remove_image: false,
        }))
        setImagePreview(URL.createObjectURL(file))
    }

    // Remove Selected Image
    const handleRemoveImage = () => {
        setFormData((prev) => ({
            ...prev,
            image: null,
            remove_image: true,
        }))
        setImagePreview(null)
        if (fileInputRef.current) {
            fileInputRef.current.value = ''
        }
    }

    // Toggle Action Button Fields
    const handleButtonToggle = (checked) => {
        setFormData((prev) => ({
            ...prev,
            has_button: checked,
            button_text: checked ? prev.button_text : '',
            button_link: checked ? prev.button_link : '',
        }))
    }

    const handleSubmit = (event) => {
        event.preventDefault()

        if (isEditing) {
            // Use POST with _method: 'put' so Laravel processes multipart/form-data file uploads on update
            router.post(route('admin.website.home.update', section.id), {
                _method: 'put',
                ...formData,
            })
        } else {
            post(route('admin.website.home.store'))
        }
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-8">

            {/* STEP 1: CONTENT DETAILS */}
            <FormSection
                step="Step 1: Content"
                icon={Layout}
                title="Home Section Details"
                description="Enter the main heading and description displayed on the website home page."
            >
                <div className="space-y-5">

                    {/* TITLE (REQUIRED) */}
                    <div>
                        <label className="mb-1.5 block text-sm font-medium text-gray-700">
                            Title <span className="text-red-500">*</span>
                        </label>

                        <input
                            type="text"
                            value={formData.title}
                            onChange={(event) =>
                                setFormData('title', event.target.value)
                            }
                            placeholder="e.g. Summer Collection 2026"
                            className="w-full max-w-md rounded-lg border border-gray-300 px-3.5 py-2.5 text-sm focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                            required
                        />

                        {errors.title && (
                            <p className="mt-1.5 text-sm text-red-600">
                                {errors.title}
                            </p>
                        )}
                    </div>

                    {/* DESCRIPTION (OPTIONAL) */}
                    <div>
                        <label className="mb-1.5 block text-sm font-medium text-gray-700">
                            Description <span className="font-normal text-gray-400">(Optional)</span>
                        </label>

                        <textarea
                            rows={3}
                            value={formData.description}
                            onChange={(event) =>
                                setFormData('description', event.target.value)
                            }
                            placeholder="Write a short subheading or promotional description for this section..."
                            className="w-full max-w-md rounded-lg border border-gray-300 px-3.5 py-2.5 text-sm focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                        />

                        {errors.description && (
                            <p className="mt-1.5 text-sm text-red-600">
                                {errors.description}
                            </p>
                        )}
                    </div>

                </div>
            </FormSection>

            {/* STEP 2: BANNER / SECTION IMAGE (OPTIONAL) */}
            <FormSection
                step="Step 2: Media"
                icon={ImageIcon}
                title="Section Image"
                description="Upload an optional banner or background image for this home section."
            >
                <div className="space-y-4">
                    <div>
                        <label className="mb-1.5 block text-sm font-medium text-gray-700">
                            Upload Image <span className="font-normal text-gray-400">(Optional)</span>
                        </label>

                        <input
                            ref={fileInputRef}
                            type="file"
                            accept="image/png, image/jpeg, image/webp"
                            onChange={handleImageChange}
                            className="hidden"
                        />

                        {!imagePreview ? (
                            <div
                                onClick={() => fileInputRef.current?.click()}
                                className="flex max-w-md cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-gray-300 bg-gray-50/50 px-6 py-8 text-center transition hover:border-violet-500 hover:bg-violet-50/30"
                            >
                                <div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-violet-100 text-violet-600">
                                    <Upload size={20} />
                                </div>
                                <p className="text-sm font-medium text-gray-700">
                                    Click to upload an image
                                </p>
                                <p className="mt-1 text-xs text-gray-500">
                                    PNG, JPG, or WEBP (Max 2MB)
                                </p>
                            </div>
                        ) : (
                            <div className="max-w-md overflow-hidden rounded-xl border border-gray-200 bg-gray-50 p-3">
                                <div className="relative aspect-video w-full overflow-hidden rounded-lg bg-gray-200">
                                    <img
                                        src={imagePreview}
                                        alt="Section Preview"
                                        className="h-full w-full object-cover"
                                    />
                                </div>

                                <div className="mt-3 flex items-center justify-between">
                                    <span className="truncate text-xs text-gray-500">
                                        {formData.image?.name || 'Current uploaded image'}
                                    </span>

                                    <div className="flex items-center gap-2">
                                        <button
                                            type="button"
                                            onClick={() => fileInputRef.current?.click()}
                                            className="rounded-md bg-white px-2.5 py-1.5 text-xs font-medium text-gray-700 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50"
                                        >
                                            Change
                                        </button>

                                        <button
                                            type="button"
                                            onClick={handleRemoveImage}
                                            className="inline-flex items-center gap-1 rounded-md bg-red-50 px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-100"
                                        >
                                            <Trash2 size={14} />
                                            Remove
                                        </button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {errors.image && (
                            <p className="mt-1.5 text-sm text-red-600">
                                {errors.image}
                            </p>
                        )}
                    </div>
                </div>
            </FormSection>

            {/* STEP 3: CALL TO ACTION (BUTTON & CONDITIONAL LINK) */}
            <FormSection
                step="Step 3: Action Button"
                icon={MousePointerClick}
                title="Button Settings"
                description="Enable a call-to-action button and specify where it should redirect visitors."
            >
                <div className="space-y-5">

                    <div>
                        <label className="flex max-w-md cursor-pointer items-start gap-3">
                            <input
                                type="checkbox"
                                checked={Boolean(formData.has_button)}
                                onChange={(event) =>
                                    handleButtonToggle(event.target.checked)
                                }
                                className="mt-1 h-5 w-5 rounded border-gray-300 text-violet-600 focus:ring-violet-600"
                            />

                            <div className="flex flex-col">
                                <span className="text-sm font-medium text-gray-700">
                                    Include Action Button
                                </span>

                                <span className="text-sm text-gray-500">
                                    Tick this option to display a clickable button inside this home section.
                                </span>
                            </div>
                        </label>
                    </div>

                    {formData.has_button && (
                        <div className="mt-4 max-w-md space-y-4 rounded-lg border border-violet-100 bg-violet-50/40 p-4 transition-all">
                            
                            <div>
                                <label className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-gray-700">
                                    <Type size={15} className="text-violet-600" />
                                    Button Text <span className="text-red-500">*</span>
                                </label>

                                <input
                                    type="text"
                                    value={formData.button_text}
                                    onChange={(event) =>
                                        setFormData('button_text', event.target.value)
                                    }
                                    placeholder="e.g. Shop Now, Explore More"
                                    className="w-full rounded-lg border border-gray-300 bg-white px-3.5 py-2 text-sm focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                                    required={formData.has_button}
                                />

                                {errors.button_text && (
                                    <p className="mt-1.5 text-sm text-red-600">
                                        {errors.button_text}
                                    </p>
                                )}
                            </div>

                            <div>
                                <label className="mb-1.5 flex items-center gap-1.5 text-sm font-medium text-gray-700">
                                    <LinkIcon size={15} className="text-violet-600" />
                                    Button Link (URL) <span className="text-red-500">*</span>
                                </label>

                                <input
                                    type="text"
                                    value={formData.button_link}
                                    onChange={(event) =>
                                        setFormData('button_link', event.target.value)
                                    }
                                    placeholder="e.g. /collections/summer or https://example.com"
                                    className="w-full rounded-lg border border-gray-300 bg-white px-3.5 py-2 text-sm focus:border-violet-600 focus:outline-none focus:ring-2 focus:ring-violet-600/20"
                                    required={formData.has_button}
                                />

                                {errors.button_link && (
                                    <p className="mt-1.5 text-sm text-red-600">
                                        {errors.button_link}
                                    </p>
                                )}
                            </div>

                        </div>
                    )}

                </div>
            </FormSection>

            {/* STEP 4: VISIBILITY STATUS */}
            <FormSection
                step="Step 4: Visibility"
                icon={Activity}
                title="Display Status"
                description="Control whether this section is visible on the live website home page."
            >
                <div className="space-y-6">

                    <div>
                        <label className="flex max-w-md cursor-pointer items-start gap-3">
                            <input
                                type="checkbox"
                                checked={Boolean(formData.status)}
                                onChange={(event) =>
                                    setFormData('status', event.target.checked)
                                }
                                className="mt-1 h-5 w-5 rounded border-gray-300 text-violet-600 focus:ring-violet-600"
                            />

                            <div className="flex flex-col">
                                <span className="text-sm font-medium text-gray-700">
                                    Show on Home Page <span className="text-red-500">*</span>
                                </span>

                                <span className="text-sm text-gray-500">
                                    Enable this option to publish this section on the storefront immediately.
                                </span>
                            </div>
                        </label>

                        {errors.status && (
                            <p className="mt-1.5 text-sm text-red-600">
                                {errors.status}
                            </p>
                        )}
                    </div>

                </div>
            </FormSection>

            {/* SUBMIT BUTTON */}
            <div className="flex justify-end pt-4">
                <button
                    type="submit"
                    disabled={processing}
                    className="inline-flex items-center justify-center gap-2 rounded-lg bg-violet-600 px-6 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-violet-500 disabled:opacity-50"
                >
                    <Save size={18} />

                    {processing
                        ? 'Saving...'
                        : isEditing
                            ? 'Update Home Section'
                            : 'Create Home Section'
                    }
                </button>
            </div>

        </form>
    )
}

export default HomeSectionForm